<?php

$conn = @mysql_connect('altran.mysql.uhserver.com','altran','murilo@12');
if (!$conn) {
	die('Could not connect: ' . mysql_error());
}
mysql_select_db('cadastroclientes', $conn);

?>